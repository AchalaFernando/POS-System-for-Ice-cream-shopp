-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2020 at 08:45 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `possystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `apassword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `apassword`) VALUES
(1, 'Sahan001', 'sm213');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` int(11) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `pnumber` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `cname`, `email`, `pnumber`) VALUES
(1, 'sahan', 'sahan23@gmail.com', 987645112),
(2, 'Achala', 'achala23@gmail.com', 712345367);

-- --------------------------------------------------------

--
-- Table structure for table `customer_comments`
--

CREATE TABLE `customer_comments` (
  `Customer_ID` int(11) NOT NULL,
  `Customer_Name` varchar(30) DEFAULT NULL,
  `Comment` varchar(100) DEFAULT NULL,
  `Phone_No` int(11) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_comments`
--

INSERT INTO `customer_comments` (`Customer_ID`, `Customer_Name`, `Comment`, `Phone_No`, `Email`) VALUES
(1, 'Achala', 'Honey nut is good', 713456789, 'achala23@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `producttable`
--

CREATE TABLE `producttable` (
  `ID` int(11) NOT NULL,
  `Product` varchar(20) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL,
  `Brand` varchar(30) DEFAULT NULL,
  `CostPrice` int(11) DEFAULT NULL,
  `RetailPrice` int(11) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL,
  `Barcode` varchar(30) DEFAULT NULL,
  `Status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `producttable`
--

INSERT INTO `producttable` (`ID`, `Product`, `Description`, `Category`, `Brand`, `CostPrice`, `RetailPrice`, `Qty`, `Barcode`, `Status`) VALUES
(2, 'ice', 'none', '3', 'sunflower', 20, 20, 5, 'sqwfek', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `user01`
--

CREATE TABLE `user01` (
  `uid` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `upassword` varchar(30) NOT NULL,
  `ucpassword` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` char(1) NOT NULL,
  `upno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user01`
--

INSERT INTO `user01` (`uid`, `uname`, `upassword`, `ucpassword`, `email`, `gender`, `upno`) VALUES
(1, 'smthissera', '123', '123', 'sahanmadu34@gmai.com', 'm', 710645112),
(2, 'madu123', '321', '321', 'madu6@gmail.com', 'f', 716089432);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `customer_comments`
--
ALTER TABLE `customer_comments`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `producttable`
--
ALTER TABLE `producttable`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user01`
--
ALTER TABLE `user01`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `producttable`
--
ALTER TABLE `producttable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
